export function App() {
    return <>
        <h1 className="text-center">Heading - 1</h1>
    </>
}