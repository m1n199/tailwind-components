// Define a functional component
function App() {
    return (
        <h1 className="text-center bg-green-400">ReactJS using CDN link !</h1>
    );
}
// Render the component in the DOM
ReactDOM.render(<App/>, document.getElementById('reactjs'));
